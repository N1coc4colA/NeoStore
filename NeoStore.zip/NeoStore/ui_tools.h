/********************************************************************************
** Form generated from reading UI file 'tools.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_TOOLS_H
#define UI_TOOLS_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_Tools
{
public:

    void setupUi(QWidget *Tools)
    {
        if (Tools->objectName().isEmpty())
            Tools->setObjectName(QStringLiteral("Tools"));
        Tools->resize(400, 300);

        retranslateUi(Tools);

        QMetaObject::connectSlotsByName(Tools);
    } // setupUi

    void retranslateUi(QWidget *Tools)
    {
        Tools->setWindowTitle(QApplication::translate("Tools", "Form", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class Tools: public Ui_Tools {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_TOOLS_H
