#include "servicemanager.h"

ServiceManager::ServiceManager()
{

}
