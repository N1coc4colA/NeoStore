#ifndef REPLYERFIXER_H
#define REPLYERFIXER_H

#include <QObject>

class ReplyerFixer : public QObject
{
    Q_OBJECT
public:
    ReplyerFixer();
};

#endif // REPLYERFIXER_H
