/********************************************************************************
** Form generated from reading UI file 'about.ui'
**
** Created by: Qt User Interface Compiler version 5.7.1
**
** WARNING! All changes made in this file will be lost when recompiling UI file!
********************************************************************************/

#ifndef UI_ABOUT_H
#define UI_ABOUT_H

#include <QtCore/QVariant>
#include <QtWidgets/QAction>
#include <QtWidgets/QApplication>
#include <QtWidgets/QButtonGroup>
#include <QtWidgets/QHBoxLayout>
#include <QtWidgets/QHeaderView>
#include <QtWidgets/QLabel>
#include <QtWidgets/QSpacerItem>
#include <QtWidgets/QVBoxLayout>
#include <QtWidgets/QWidget>

QT_BEGIN_NAMESPACE

class Ui_About
{
public:
    QHBoxLayout *horizontalLayout_2;
    QWidget *widget;
    QVBoxLayout *verticalLayout_2;
    QHBoxLayout *horizontalLayout_3;
    QSpacerItem *horizontalSpacer;
    QLabel *LOGO;
    QSpacerItem *horizontalSpacer_2;
    QHBoxLayout *horizontalLayout_5;
    QLabel *TITLE;
    QLabel *label_3;
    QLabel *hyperlink;
    QLabel *label_4;
    QWidget *widget_2;
    QVBoxLayout *verticalLayout;
    QLabel *label;
    QHBoxLayout *horizontalLayout;
    QLabel *QtContrib;
    QLabel *KDEContrib;
    QWidget *widget_3;
    QHBoxLayout *horizontalLayout_4;
    QLabel *DDEContrib;
    QLabel *QAPTContrib;
    QLabel *label_8;
    QLabel *label_9;
    QLabel *label_2;

    void setupUi(QWidget *About)
    {
        if (About->objectName().isEmpty())
            About->setObjectName(QStringLiteral("About"));
        About->resize(680, 410);
        About->setMinimumSize(QSize(680, 410));
        About->setMaximumSize(QSize(680, 410));
        QFont font;
        font.setPointSize(9);
        About->setFont(font);
        horizontalLayout_2 = new QHBoxLayout(About);
        horizontalLayout_2->setObjectName(QStringLiteral("horizontalLayout_2"));
        horizontalLayout_2->setContentsMargins(0, 0, 0, 0);
        widget = new QWidget(About);
        widget->setObjectName(QStringLiteral("widget"));
        widget->setMaximumSize(QSize(400, 16777215));
        verticalLayout_2 = new QVBoxLayout(widget);
        verticalLayout_2->setSpacing(0);
        verticalLayout_2->setObjectName(QStringLiteral("verticalLayout_2"));
        verticalLayout_2->setContentsMargins(0, 0, 0, 0);
        horizontalLayout_3 = new QHBoxLayout();
        horizontalLayout_3->setSpacing(0);
        horizontalLayout_3->setObjectName(QStringLiteral("horizontalLayout_3"));
        horizontalLayout_3->setContentsMargins(-1, -1, 0, 0);
        horizontalSpacer = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer);

        LOGO = new QLabel(widget);
        LOGO->setObjectName(QStringLiteral("LOGO"));
        LOGO->setMinimumSize(QSize(150, 150));
        LOGO->setMaximumSize(QSize(140, 140));

        horizontalLayout_3->addWidget(LOGO);

        horizontalSpacer_2 = new QSpacerItem(40, 20, QSizePolicy::Expanding, QSizePolicy::Minimum);

        horizontalLayout_3->addItem(horizontalSpacer_2);


        verticalLayout_2->addLayout(horizontalLayout_3);

        horizontalLayout_5 = new QHBoxLayout();
        horizontalLayout_5->setSpacing(0);
        horizontalLayout_5->setObjectName(QStringLiteral("horizontalLayout_5"));
        horizontalLayout_5->setSizeConstraint(QLayout::SetMinimumSize);
        TITLE = new QLabel(widget);
        TITLE->setObjectName(QStringLiteral("TITLE"));
        QSizePolicy sizePolicy(QSizePolicy::Maximum, QSizePolicy::Fixed);
        sizePolicy.setHorizontalStretch(0);
        sizePolicy.setVerticalStretch(0);
        sizePolicy.setHeightForWidth(TITLE->sizePolicy().hasHeightForWidth());
        TITLE->setSizePolicy(sizePolicy);
        TITLE->setMinimumSize(QSize(0, 75));
        TITLE->setMaximumSize(QSize(16777215, 75));
        TITLE->setBaseSize(QSize(0, 75));
        QFont font1;
        font1.setPointSize(50);
        font1.setBold(true);
        font1.setWeight(75);
        TITLE->setFont(font1);
        TITLE->setAlignment(Qt::AlignCenter);

        horizontalLayout_5->addWidget(TITLE);


        verticalLayout_2->addLayout(horizontalLayout_5);

        label_3 = new QLabel(widget);
        label_3->setObjectName(QStringLiteral("label_3"));
        label_3->setMaximumSize(QSize(16777215, 40));
        QFont font2;
        font2.setPointSize(13);
        label_3->setFont(font2);
        label_3->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(label_3);

        hyperlink = new QLabel(widget);
        hyperlink->setObjectName(QStringLiteral("hyperlink"));
        QSizePolicy sizePolicy1(QSizePolicy::Minimum, QSizePolicy::Minimum);
        sizePolicy1.setHorizontalStretch(0);
        sizePolicy1.setVerticalStretch(0);
        sizePolicy1.setHeightForWidth(hyperlink->sizePolicy().hasHeightForWidth());
        hyperlink->setSizePolicy(sizePolicy1);
        hyperlink->setMinimumSize(QSize(0, 20));
        hyperlink->setMaximumSize(QSize(16777215, 20));
        hyperlink->setAlignment(Qt::AlignCenter);

        verticalLayout_2->addWidget(hyperlink);

        label_4 = new QLabel(widget);
        label_4->setObjectName(QStringLiteral("label_4"));
        QSizePolicy sizePolicy2(QSizePolicy::Preferred, QSizePolicy::Preferred);
        sizePolicy2.setHorizontalStretch(0);
        sizePolicy2.setVerticalStretch(0);
        sizePolicy2.setHeightForWidth(label_4->sizePolicy().hasHeightForWidth());
        label_4->setSizePolicy(sizePolicy2);
        label_4->setMinimumSize(QSize(0, 0));
        label_4->setMaximumSize(QSize(16777215, 16777215));
        QFont font3;
        font3.setFamily(QStringLiteral("Sans Serif"));
        font3.setPointSize(10);
        font3.setKerning(true);
        label_4->setFont(font3);
        label_4->setAlignment(Qt::AlignJustify|Qt::AlignVCenter);
        label_4->setWordWrap(true);

        verticalLayout_2->addWidget(label_4);


        horizontalLayout_2->addWidget(widget);

        widget_2 = new QWidget(About);
        widget_2->setObjectName(QStringLiteral("widget_2"));
        verticalLayout = new QVBoxLayout(widget_2);
        verticalLayout->setSpacing(0);
        verticalLayout->setObjectName(QStringLiteral("verticalLayout"));
        label = new QLabel(widget_2);
        label->setObjectName(QStringLiteral("label"));
        QSizePolicy sizePolicy3(QSizePolicy::Fixed, QSizePolicy::Fixed);
        sizePolicy3.setHorizontalStretch(0);
        sizePolicy3.setVerticalStretch(0);
        sizePolicy3.setHeightForWidth(label->sizePolicy().hasHeightForWidth());
        label->setSizePolicy(sizePolicy3);
        label->setMinimumSize(QSize(0, 75));
        label->setMaximumSize(QSize(16777215, 75));
        label->setScaledContents(true);
        label->setWordWrap(true);

        verticalLayout->addWidget(label);

        horizontalLayout = new QHBoxLayout();
        horizontalLayout->setObjectName(QStringLiteral("horizontalLayout"));
        QtContrib = new QLabel(widget_2);
        QtContrib->setObjectName(QStringLiteral("QtContrib"));
        sizePolicy3.setHeightForWidth(QtContrib->sizePolicy().hasHeightForWidth());
        QtContrib->setSizePolicy(sizePolicy3);
        QtContrib->setMinimumSize(QSize(100, 100));
        QtContrib->setMaximumSize(QSize(100, 100));

        horizontalLayout->addWidget(QtContrib);

        KDEContrib = new QLabel(widget_2);
        KDEContrib->setObjectName(QStringLiteral("KDEContrib"));
        sizePolicy3.setHeightForWidth(KDEContrib->sizePolicy().hasHeightForWidth());
        KDEContrib->setSizePolicy(sizePolicy3);
        KDEContrib->setMinimumSize(QSize(100, 100));
        KDEContrib->setMaximumSize(QSize(100, 100));

        horizontalLayout->addWidget(KDEContrib);


        verticalLayout->addLayout(horizontalLayout);

        widget_3 = new QWidget(widget_2);
        widget_3->setObjectName(QStringLiteral("widget_3"));
        sizePolicy3.setHeightForWidth(widget_3->sizePolicy().hasHeightForWidth());
        widget_3->setSizePolicy(sizePolicy3);
        widget_3->setMinimumSize(QSize(0, 20));
        widget_3->setMaximumSize(QSize(16777215, 20));

        verticalLayout->addWidget(widget_3);

        horizontalLayout_4 = new QHBoxLayout();
        horizontalLayout_4->setObjectName(QStringLiteral("horizontalLayout_4"));
        DDEContrib = new QLabel(widget_2);
        DDEContrib->setObjectName(QStringLiteral("DDEContrib"));
        sizePolicy3.setHeightForWidth(DDEContrib->sizePolicy().hasHeightForWidth());
        DDEContrib->setSizePolicy(sizePolicy3);
        DDEContrib->setMinimumSize(QSize(150, 45));
        DDEContrib->setMaximumSize(QSize(150, 16777215));

        horizontalLayout_4->addWidget(DDEContrib);


        verticalLayout->addLayout(horizontalLayout_4);

        QAPTContrib = new QLabel(widget_2);
        QAPTContrib->setObjectName(QStringLiteral("QAPTContrib"));
        QAPTContrib->setWordWrap(true);

        verticalLayout->addWidget(QAPTContrib);

        label_8 = new QLabel(widget_2);
        label_8->setObjectName(QStringLiteral("label_8"));
        label_8->setWordWrap(true);

        verticalLayout->addWidget(label_8);

        label_9 = new QLabel(widget_2);
        label_9->setObjectName(QStringLiteral("label_9"));
        label_9->setMinimumSize(QSize(0, 80));
        label_9->setMaximumSize(QSize(16777215, 80));
        label_9->setWordWrap(true);

        verticalLayout->addWidget(label_9);

        label_2 = new QLabel(widget_2);
        label_2->setObjectName(QStringLiteral("label_2"));
        label_2->setMaximumSize(QSize(16777215, 20));

        verticalLayout->addWidget(label_2);


        horizontalLayout_2->addWidget(widget_2);


        retranslateUi(About);

        QMetaObject::connectSlotsByName(About);
    } // setupUi

    void retranslateUi(QWidget *About)
    {
        About->setWindowTitle(QApplication::translate("About", "Form", Q_NULLPTR));
        LOGO->setText(QString());
        TITLE->setText(QApplication::translate("About", "NeoStore", Q_NULLPTR));
        label_3->setText(QApplication::translate("About", "Version: 0.5", Q_NULLPTR));
        hyperlink->setText(QString());
        label_4->setText(QApplication::translate("About", "The NeoStore is a simple and easy to use package manager for APT. This project is independent and Open Source, to make every one able to see the flaws, help this project or learn how to develop. This project uses some libraries and other external components, like Git. This project is the first official release of an app from @n1coc4cola, and it should have a long time support (LTS).", Q_NULLPTR));
        label->setText(QApplication::translate("About", "Thanks to all the contributors, having participated directly or indirectly in this project, or without even having knowledge of it.", Q_NULLPTR));
        QtContrib->setText(QString());
        KDEContrib->setText(QString());
        DDEContrib->setText(QString());
        QAPTContrib->setText(QApplication::translate("About", "Thanks to the KDE Extras developer team for libqapt, otherwise this whole project would have been impossible.", Q_NULLPTR));
        label_8->setText(QApplication::translate("About", "Deepin Latin Code and its members for the ideas I had from them (if they don't know).", Q_NULLPTR));
        label_9->setText(QApplication::translate("About", "Thanks to all the Linux Open Source community (and not only this one), which made me learn how to develop in a lot of different languages.", Q_NULLPTR));
        label_2->setText(QApplication::translate("About", "@n1coc4cola, Thanks you all.", Q_NULLPTR));
    } // retranslateUi

};

namespace Ui {
    class About: public Ui_About {};
} // namespace Ui

QT_END_NAMESPACE

#endif // UI_ABOUT_H
