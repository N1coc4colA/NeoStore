#ifndef SERVICEMANAGER_H
#define SERVICEMANAGER_H

#include <QObject>
#include <QWidget>

class ServiceManager
{
public:
    ServiceManager();
};

#endif // SERVICEMANAGER_H
