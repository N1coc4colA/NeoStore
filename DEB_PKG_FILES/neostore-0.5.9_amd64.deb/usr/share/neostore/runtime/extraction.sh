!#/bin/bash
cd /tmp/nui && unzip /tmp/nui/master -d /tmp/nui/